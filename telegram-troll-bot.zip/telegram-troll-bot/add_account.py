import os
import rich
import random
import glob

from pyrogram import Client

from rich.console import Console
from rich.prompt import Confirm

from functions import (
    api_id,
    api_hash,
    session_name,
    device_model,
    system_version
)

console = Console()

def ask():
    options = [
       "Add account",
       "Delete session"
    ]

    for number, options in enumerate(
        options,
        start = 1
    ):
      console.print(f"[{number}] - {options}", style="bold")

ask()


choice = console.input("[bold]>> ")

if choice == "1":

    device_model = random.choice(device_model)
          
    app = Client(
       session_name,
       api_id=api_id,
       api_hash=api_hash,
       device_model=device_model,
       system_version=system_version
    )
    
    with app:
         acc = app.get_me()

    console.print(f"[bold green][+][/] {acc.first_name} / {acc.id}")

elif choice == "2":
     delete = Confirm.ask("[bold red]delete all sessions?")

     if not delete:
        name_session = console.input("[bold red]Session name: ")
        os.remove(f"{name_session}.session")
        console.print(f"[+] {name_session}.session - Deleted")
        
     else:
         for sessions in glob.glob("*.session"):
             os.remove(sessions)
             console.print(f"[+] {sessions} - Deleted")
